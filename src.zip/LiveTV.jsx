import React, { useState } from 'react';

export default function LiveTV() {
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Später von XuiOne API laden
  const categories = [
    { id: 1, name: 'Tüm Kanallar', count: 245 },
    { id: 2, name: 'Türkiye Kanalları', count: 87 },
    { id: 3, name: 'Haber', count: 24 },
    { id: 4, name: 'Spor', count: 45 },
    { id: 5, name: 'Film', count: 32 },
    { id: 6, name: 'Çocuk', count: 18 },
    { id: 7, name: 'Belgesel', count: 15 },
    { id: 8, name: 'Müzik', count: 24 },
  ];

  // Später von XuiOne API laden basierend auf selectedCategory
  const channels = [
    { id: 1, name: 'TRT 1 HD', logo: '🇹🇷', category: 'Türkiye Kanalları', isLive: true },
    { id: 2, name: 'Show TV HD', logo: '📺', category: 'Türkiye Kanalları', isLive: true },
    { id: 3, name: 'Kanal D HD', logo: '📺', category: 'Türkiye Kanalları', isLive: true },
    { id: 4, name: 'ATV HD', logo: '📺', category: 'Türkiye Kanalları', isLive: true },
    { id: 5, name: 'Star TV HD', logo: '⭐', category: 'Türkiye Kanalları', isLive: true },
    { id: 6, name: 'CNN Türk HD', logo: '📰', category: 'Haber', isLive: true },
    { id: 7, name: 'NTV HD', logo: '📰', category: 'Haber', isLive: true },
    { id: 8, name: 'Haber Türk HD', logo: '📰', category: 'Haber', isLive: true },
    { id: 9, name: 'beIN Sports 1 HD', logo: '⚽', category: 'Spor', isLive: true },
    { id: 10, name: 'TRT Spor HD', logo: '🏆', category: 'Spor', isLive: true },
    { id: 11, name: 'S Sport HD', logo: '⚽', category: 'Spor', isLive: true },
    { id: 12, name: 'TRT Çocuk HD', logo: '🎈', category: 'Çocuk', isLive: true },
  ];

  const filteredChannels = channels.filter(channel => 
    channel.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex h-[calc(100vh-140px)] gap-4">
      {/* Categories Sidebar */}
      <div className="w-80 bg-slate-900/50 backdrop-blur-sm rounded-xl border border-slate-800/30 overflow-hidden flex flex-col">
        <div className="p-4 border-b border-slate-800/50">
          <h2 className="text-lg font-bold text-white flex items-center" style={{fontFamily: 'Outfit, sans-serif'}}>
            <span className="text-2xl mr-2">📂</span>
            Kategoriler
          </h2>
        </div>
        
        <div className="flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-slate-700 scrollbar-track-transparent">
          <div className="p-2">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`w-full text-left px-4 py-3 rounded-lg mb-1 transition-all duration-200 flex items-center justify-between group ${
                  selectedCategory === category.id
                    ? 'bg-red-500/20 text-white border border-red-500/30'
                    : 'text-slate-300 hover:bg-slate-800/50 hover:text-white'
                }`}
              >
                <span className="font-medium">{category.name}</span>
                <span className={`text-xs px-2 py-1 rounded-full ${
                  selectedCategory === category.id
                    ? 'bg-red-500/30 text-red-300'
                    : 'bg-slate-800/50 text-slate-500 group-hover:bg-slate-700/50 group-hover:text-slate-400'
                }`}>
                  {category.count}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Channels List */}
      <div className="flex-1 bg-slate-900/50 backdrop-blur-sm rounded-xl border border-slate-800/30 overflow-hidden flex flex-col">
        {/* Search Header */}
        <div className="p-4 border-b border-slate-800/50">
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Kanal Ara..."
              className="w-full bg-slate-800/50 border border-slate-700/50 rounded-xl px-4 py-3 pl-12 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-red-500/50 focus:border-transparent transition-all"
            />
            <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
        </div>

        {/* Channels List */}
        <div className="flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-slate-700 scrollbar-track-transparent">
          <div className="p-2">
            {filteredChannels.length === 0 ? (
              <div className="text-center py-12 text-slate-500">
                <svg className="w-16 h-16 mx-auto mb-4 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <p className="font-medium">Kanal bulunamadı</p>
              </div>
            ) : (
              filteredChannels.map((channel) => (
                <button
                  key={channel.id}
                  className="w-full flex items-center gap-4 px-4 py-3 rounded-lg mb-1 transition-all duration-200 hover:bg-slate-800/50 group cursor-pointer border border-transparent hover:border-red-500/30"
                >
                  {/* Channel Logo */}
                  <div className="w-16 h-16 bg-gradient-to-br from-slate-800 to-slate-900 rounded-lg flex items-center justify-center text-3xl border border-slate-700/50 group-hover:border-red-500/30 transition-all flex-shrink-0">
                    {channel.logo}
                  </div>

                  {/* Channel Info */}
                  <div className="flex-1 text-left min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold text-white group-hover:text-red-400 transition-colors truncate">
                        {channel.name}
                      </h3>
                      {channel.isLive && (
                        <span className="flex items-center gap-1 bg-red-500/20 text-red-400 text-xs font-bold px-2 py-0.5 rounded-full border border-red-500/30 flex-shrink-0">
                          <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse"></span>
                          CANLI
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-slate-500 truncate">{channel.category}</p>
                  </div>

                  {/* Play Icon */}
                  <div className="flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="w-10 h-10 bg-red-500/20 rounded-full flex items-center justify-center">
                      <svg className="w-5 h-5 text-red-400" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M8 5v14l11-7z"/>
                      </svg>
                    </div>
                  </div>
                </button>
              ))
            )}
          </div>
        </div>

        {/* Footer Info */}
        <div className="p-3 border-t border-slate-800/50 bg-slate-900/30">
          <p className="text-xs text-slate-500 text-center">
            {filteredChannels.length} kanal gösteriliyor
          </p>
        </div>
      </div>

      <style jsx>{`
        .scrollbar-thin::-webkit-scrollbar {
          width: 6px;
        }
        .scrollbar-thin::-webkit-scrollbar-track {
          background: transparent;
        }
        .scrollbar-thin::-webkit-scrollbar-thumb {
          background: rgb(51 65 85);
          border-radius: 3px;
        }
        .scrollbar-thin::-webkit-scrollbar-thumb:hover {
          background: rgb(71 85 105);
        }
      `}</style>
    </div>
  );
}
