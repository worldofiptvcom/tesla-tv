import React, { useState, useEffect } from 'react';
import Login from './Login';
import Header from './Header';
import LiveTV from './LiveTV';
import Movies from './Movies';
import Series from './Series';

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userData, setUserData] = useState(null);
  const [activeTab, setActiveTab] = useState('live');

  // Check for saved credentials on mount
  useEffect(() => {
    const savedCredentials = localStorage.getItem('tesla_tv_credentials');
    if (savedCredentials) {
      try {
        const { username, password, timestamp } = JSON.parse(savedCredentials);
        // Auto-login wenn gespeicherte Credentials vorhanden sind
        // Später: Validate mit XuiOne API
        setUserData({ username });
        setIsLoggedIn(true);
      } catch (error) {
        console.error('Error loading saved credentials:', error);
      }
    }
  }, []);

  const handleLogin = (credentials) => {
    // Später: XuiOne API Login
    setUserData({ username: credentials.username });
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUserData(null);
    localStorage.removeItem('tesla_tv_credentials');
  };

  if (!isLoggedIn) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <Header username={userData?.username} onLogout={handleLogout} />

      {/* Main Navigation */}
      <nav className="bg-slate-900/50 backdrop-blur-sm border-b border-slate-800/30 sticky top-[73px] z-40">
        <div className="container mx-auto px-6">
          <div className="flex space-x-2">
            {[
              { id: 'live', label: 'Canlı TV', icon: '📡' },
              { id: 'movies', label: 'Filmler', icon: '🎬' },
              { id: 'series', label: 'Diziler', icon: '📺' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-6 py-4 font-semibold transition-all duration-300 border-b-2 ${
                  activeTab === tab.id
                    ? 'border-red-500 text-white bg-slate-800/50'
                    : 'border-transparent text-slate-400 hover:text-white hover:bg-slate-800/30'
                }`}
              >
                <span className="text-xl">{tab.icon}</span>
                <span style={{fontFamily: 'Outfit, sans-serif'}}>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Content Area */}
      <main className="container mx-auto px-6 py-8">
        {activeTab === 'live' && <LiveTV />}
        {activeTab === 'movies' && <Movies />}
        {activeTab === 'series' && <Series />}
      </main>

      <style jsx>{`
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap');
      `}</style>
    </div>
  );
}
