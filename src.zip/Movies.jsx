import React, { useState } from 'react';

export default function Movies() {
  const [searchQuery, setSearchQuery] = useState('');

  // Später von XuiOne API laden
  const movies = [
    { id: 1, title: 'Aksiyon Filmi 1', year: 2024, genre: 'Aksiyon', duration: '2h 15m' },
    { id: 2, title: 'Komedi Filmi 1', year: 2024, genre: 'Komedi', duration: '1h 45m' },
    { id: 3, title: 'Drama Filmi 1', year: 2023, genre: 'Drama', duration: '2h 30m' },
    { id: 4, title: 'Korku Filmi 1', year: 2024, genre: 'Korku', duration: '1h 55m' },
    { id: 5, title: 'Bilim Kurgu 1', year: 2024, genre: 'Bilim Kurgu', duration: '2h 10m' },
    { id: 6, title: 'Romantik Film 1', year: 2023, genre: 'Romantik', duration: '1h 50m' },
    { id: 7, title: 'Macera Filmi 1', year: 2024, genre: 'Macera', duration: '2h 20m' },
    { id: 8, title: 'Animasyon 1', year: 2024, genre: 'Animasyon', duration: '1h 40m' },
    { id: 9, title: 'Gerilim Filmi 1', year: 2023, genre: 'Gerilim', duration: '2h 5m' },
    { id: 10, title: 'Aksiyon Filmi 2', year: 2024, genre: 'Aksiyon', duration: '2h 00m' },
    { id: 11, title: 'Komedi Filmi 2', year: 2024, genre: 'Komedi', duration: '1h 35m' },
    { id: 12, title: 'Drama Filmi 2', year: 2023, genre: 'Drama', duration: '2h 25m' },
  ];

  const filteredMovies = movies.filter(movie =>
    movie.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Search Bar */}
      <div className="relative max-w-2xl">
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Film Ara..."
          className="w-full bg-slate-900/50 border border-slate-800/50 rounded-xl px-5 py-3.5 pl-12 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-red-500/50 focus:border-transparent transition-all backdrop-blur-sm"
        />
        <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
      </div>

      {/* Movies Grid */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold" style={{fontFamily: 'Outfit, sans-serif', letterSpacing: '-0.02em'}}>
            🎬 Filmler
          </h2>
          <p className="text-sm text-slate-500">{filteredMovies.length} film</p>
        </div>

        {filteredMovies.length === 0 ? (
          <div className="text-center py-20 text-slate-500">
            <svg className="w-20 h-20 mx-auto mb-4 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 4v16M17 4v16M3 8h4m10 0h4M3 12h18M3 16h4m10 0h4M4 20h16a1 1 0 001-1V5a1 1 0 00-1-1H4a1 1 0 00-1 1v14a1 1 0 001 1z" />
            </svg>
            <p className="font-medium text-lg">Film bulunamadı</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {filteredMovies.map((movie) => (
              <div
                key={movie.id}
                className="group relative bg-slate-900/50 backdrop-blur-sm rounded-xl overflow-hidden border border-slate-800/30 hover:border-red-500/50 transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-red-500/10 cursor-pointer"
              >
                {/* Poster */}
                <div className="aspect-[2/3] bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-red-500/20 to-orange-600/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                  <svg className="w-16 h-16 text-slate-700 group-hover:text-red-500 transition-colors" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M8 5v14l11-7z"/>
                  </svg>
                </div>

                {/* Info */}
                <div className="p-3">
                  <h3 className="font-semibold text-sm mb-1 truncate group-hover:text-red-400 transition-colors">
                    {movie.title}
                  </h3>
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <span>{movie.year}</span>
                    <span>•</span>
                    <span>{movie.duration}</span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">{movie.genre}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
