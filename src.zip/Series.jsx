import React, { useState } from 'react';

export default function Series() {
  const [searchQuery, setSearchQuery] = useState('');

  // Später von XuiOne API laden
  const series = [
    { id: 1, title: 'Aksiyon Dizisi 1', year: 2024, genre: 'Aksiyon', seasons: 3, episodes: 45 },
    { id: 2, title: 'Drama Dizisi 1', year: 2023, genre: 'Drama', seasons: 5, episodes: 120 },
    { id: 3, title: 'Komedi Dizisi 1', year: 2024, genre: 'Komedi', seasons: 2, episodes: 24 },
    { id: 4, title: 'Suç Dizisi 1', year: 2024, genre: 'Suç', seasons: 4, episodes: 80 },
    { id: 5, title: 'Bilim Kurgu Dizisi 1', year: 2023, genre: 'Bilim Kurgu', seasons: 2, episodes: 20 },
    { id: 6, title: 'Gerilim Dizisi 1', year: 2024, genre: 'Gerilim', seasons: 3, episodes: 36 },
    { id: 7, title: 'Fantastik Dizi 1', year: 2024, genre: 'Fantastik', seasons: 4, episodes: 48 },
    { id: 8, title: 'Tarihi Dizi 1', year: 2023, genre: 'Tarihi', seasons: 2, episodes: 30 },
    { id: 9, title: 'Romantik Dizi 1', year: 2024, genre: 'Romantik', seasons: 3, episodes: 42 },
    { id: 10, title: 'Aksiyon Dizisi 2', year: 2024, genre: 'Aksiyon', seasons: 1, episodes: 12 },
    { id: 11, title: 'Drama Dizisi 2', year: 2023, genre: 'Drama', seasons: 6, episodes: 144 },
    { id: 12, title: 'Komedi Dizisi 2', year: 2024, genre: 'Komedi', seasons: 3, episodes: 36 },
  ];

  const filteredSeries = series.filter(show =>
    show.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Search Bar */}
      <div className="relative max-w-2xl">
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Dizi Ara..."
          className="w-full bg-slate-900/50 border border-slate-800/50 rounded-xl px-5 py-3.5 pl-12 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-red-500/50 focus:border-transparent transition-all backdrop-blur-sm"
        />
        <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
      </div>

      {/* Series Grid */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold" style={{fontFamily: 'Outfit, sans-serif', letterSpacing: '-0.02em'}}>
            📺 Diziler
          </h2>
          <p className="text-sm text-slate-500">{filteredSeries.length} dizi</p>
        </div>

        {filteredSeries.length === 0 ? (
          <div className="text-center py-20 text-slate-500">
            <svg className="w-20 h-20 mx-auto mb-4 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
            </svg>
            <p className="font-medium text-lg">Dizi bulunamadı</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {filteredSeries.map((show) => (
              <div
                key={show.id}
                className="group relative bg-slate-900/50 backdrop-blur-sm rounded-xl overflow-hidden border border-slate-800/30 hover:border-red-500/50 transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-red-500/10 cursor-pointer"
              >
                {/* Poster */}
                <div className="aspect-[2/3] bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-red-500/20 to-orange-600/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                  <svg className="w-16 h-16 text-slate-700 group-hover:text-red-500 transition-colors" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M8 5v14l11-7z"/>
                  </svg>
                  
                  {/* Season Badge */}
                  <div className="absolute top-2 right-2 bg-red-500/90 text-white text-xs font-bold px-2 py-1 rounded-lg backdrop-blur-sm">
                    {show.seasons} Sezon
                  </div>
                </div>

                {/* Info */}
                <div className="p-3">
                  <h3 className="font-semibold text-sm mb-1 truncate group-hover:text-red-400 transition-colors">
                    {show.title}
                  </h3>
                  <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                    <span>{show.year}</span>
                    <span>•</span>
                    <span>{show.episodes} Bölüm</span>
                  </div>
                  <p className="text-xs text-slate-600">{show.genre}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
